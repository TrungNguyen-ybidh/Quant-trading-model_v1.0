from trend_filter import classify_trend_bias
import pandas as pd

ltf = pd.read_csv("data/BTC_LTF_15m.csv", index_col=0)
htf = pd.read_csv('data/BTC_HTF_1h.csv', index_col=0)

ltf_with_trend = classify_trend_bias(ltf, htf)
ltf_with_trend.to_csv("BTC_LTF_15m_with_trend.csv")