from ote_zone import calculate_ote_zones
import pandas as pd

ltf = pd.read_csv("break_out/BTC_LTF_15m_with_Breakouts.csv", index_col=0)
ltf = calculate_ote_zones(ltf)
ltf.to_csv("BTC_LTF_15m_with_ote.csv")
