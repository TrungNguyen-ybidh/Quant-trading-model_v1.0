from entry_trigger import detect_entry_signals
import pandas as pd


ltf = pd.read_csv("ote_zone/BTC_LTF_15m_with_ote.csv", index_col=0)
ltf = detect_entry_signals(ltf)
ltf.to_csv("BTC_LTF_15m_with_entries.csv")
