from risk_reward import set_risk_reward
import pandas as pd

ltf = pd.read_csv("entry_trigger/BTC_LTF_15m_with_entries.csv", index_col=0)
ltf = set_risk_reward(ltf)
ltf.to_csv("BTC_LTF_15m_with_risk_reward.csv")
