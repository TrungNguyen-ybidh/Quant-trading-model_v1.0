from backtest import run_backtest
import pandas as pd

ltf = pd.read_csv("risk_reward/BTC_LTF_15m_with_risk_reward.csv", index_col=0)
ltf = run_backtest(ltf)
ltf.to_csv("BTC_LTF_15m_backtest_results.csv")
