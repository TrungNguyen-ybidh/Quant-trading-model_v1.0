from breakout_detector import detect_breakouts
import pandas as pd 

ltf = pd.read_csv('trend_filter/BTC_LTF_15m_with_trend.csv', index_col=0)
ltf = detect_breakouts(ltf)
ltf.to_csv("BTC_LTF_15m_with_Breakouts.csv")