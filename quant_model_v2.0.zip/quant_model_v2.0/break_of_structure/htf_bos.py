def detect_htf_bos(df, swing_window=3):
    """
    Detect Break of Structure (BOS) on the higher time frame (HTF).
    BOS is defined as a close above previous swing high (bullish) or below swing low (bearish).
    """
    df = df.copy()
    df["is_bos"] = False
    df["bos_type"] = None
    
    swing_highs = []
    swing_lows = []

    for i in range(swing_window, len(df) - swing_window):
        high = df.iloc[i]["High"]
        low = df.iloc[i]["Low"]

        # Detect swing high
        if high == max(df.iloc[i - swing_window: i + swing_window + 1]["High"]):
            swing_highs.append((i, high))

        # Detect swing low
        if low == min(df.iloc[i - swing_window: i + swing_window + 1]["Low"]):
            swing_lows.append((i, low))

    # Check for BOS
    for j in range(1, len(swing_highs)):
        idx_prev, prev_high = swing_highs[j - 1]
        idx_curr, curr_high = swing_highs[j]

        if df.iloc[idx_curr]["Close"] > prev_high:
            df.at[df.index[idx_curr], "is_bos"] = True
            df.at[df.index[idx_curr], "bos_type"] = "bullish"

    for j in range(1, len(swing_lows)):
        idx_prev, prev_low = swing_lows[j - 1]
        idx_curr, curr_low = swing_lows[j]

        if df.iloc[idx_curr]["Close"] < prev_low:
            df.at[df.index[idx_curr], "is_bos"] = True
            df.at[df.index[idx_curr], "bos_type"] = "bearish"

    return df

