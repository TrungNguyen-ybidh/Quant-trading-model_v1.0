def detect_htf_choch(df, swing_window=3):
    """
    Detect Change of Character (CHoCH) on the higher time frame (HTF).
    CHoCH is defined as price closing above a LH after forming LL (bullish), or
    closing below a HL after forming HH (bearish).
    """
    df = df.copy()
    df["is_choch"] = False
    df["choch_type"] = None

    structure = []  # Holds detected swing structure: [("type", idx, price)]

    for i in range(swing_window, len(df) - swing_window):
        high = df.iloc[i]["High"]
        low = df.iloc[i]["Low"]

        if high == max(df.iloc[i - swing_window: i + swing_window + 1]["High"]):
            structure.append(("swing_high", i, high))

        if low == min(df.iloc[i - swing_window: i + swing_window + 1]["Low"]):
            structure.append(("swing_low", i, low))

    for j in range(2, len(structure)):
        (t1, i1, p1), (t2, i2, p2), (t3, i3, p3) = structure[j - 2], structure[j - 1], structure[j]

        # Bullish CHoCH: swing_low (LL) -> swing_high (LH) -> close above LH
        if t1 == "swing_low" and t2 == "swing_high" and t3 == "swing_high":
            if df.iloc[i3]["Close"] > p2:
                df.at[df.index[i3], "is_choch"] = True
                df.at[df.index[i3], "choch_type"] = "bullish"

        # Bearish CHoCH: swing_high (HH) -> swing_low (HL) -> close below HL
        if t1 == "swing_high" and t2 == "swing_low" and t3 == "swing_low":
            if df.iloc[i3]["Close"] < p2:
                df.at[df.index[i3], "is_choch"] = True
                df.at[df.index[i3], "choch_type"] = "bearish"

    return df