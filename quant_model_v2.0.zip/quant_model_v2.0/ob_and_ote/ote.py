def detect_ote_zones(df, bos_swing_ranges, direction):
    """
    Detect OTE (Optimal Trade Entry) zones based on BOS/CHoCH swing ranges.

    Parameters:
    - df: DataFrame with OHLC data
    - bos_swing_ranges: List of tuples (start_idx, end_idx) defining the swing
    - direction: "bullish" or "bearish"

    Adds:
    - ote_start: 0.62 level
    - ote_end: 0.79 level
    - ote_best: 0.705 level (best entry)
    - ote_dir: 'bullish' or 'bearish'
    """

    fib_levels = [1.0, 0.79, 0.705, 0.62, 0.5, 0.0, -0.27, -0.62]
    df = df.copy()
    df["ote_start"] = None
    df["ote_end"] = None
    df["ote_best"] = None
    df["ote_dir"] = None

    for start_idx, end_idx in bos_swing_ranges:
        if start_idx >= len(df) or end_idx >= len(df):
            continue

        high = df.iloc[start_idx]["High"]
        low = df.iloc[end_idx]["Low"]

        if direction == "bullish" and high > low:
            diff = high - low
            level_62 = low + diff * 0.62
            level_79 = low + diff * 0.79
            level_705 = low + diff * 0.705
        elif direction == "bearish" and high > low:
            diff = high - low
            level_62 = high - diff * 0.62
            level_79 = high - diff * 0.79
            level_705 = high - diff * 0.705
        else:
            continue  # Invalid swing

        df.at[df.index[end_idx], "ote_start"] = min(level_62, level_79)
        df.at[df.index[end_idx], "ote_end"] = max(level_62, level_79)
        df.at[df.index[end_idx], "ote_best"] = level_705
        df.at[df.index[end_idx], "ote_dir"] = direction

    return df

