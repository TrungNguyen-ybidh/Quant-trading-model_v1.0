import pandas as pd

def prioritize_ob_over_ote(df):
    """
    Prioritize OB if all requirements are met:
    - OB must exist (is_ob == True)
    - OB must lie within a BOS/CHoCH swing range (already handled in OB detection)
    - OB must include a valid FVG (already filtered in OB logic)

    If OB is valid, use OB start/end as entry zone.
    Else, use OTE zone.
    
    Adds:
    - zone_start: float (start of entry zone)
    - zone_end: float (end of entry zone)
    - zone_type: 'OB' or 'OTE'
    """

    df = df.copy()
    df["zone_start"] = None
    df["zone_end"] = None
    df["zone_type"] = None

    for i in range(len(df)):
        if df.loc[df.index[i], "is_ob"]:
            # Use OB if valid
            df.loc[df.index[i], "zone_start"] = df.loc[df.index[i], "ob_start"]
            df.loc[df.index[i], "zone_end"] = df.loc[df.index[i], "ob_end"]
            df.loc[df.index[i], "zone_type"] = "OB"
        elif pd.notna(df.loc[df.index[i], "ote_start"]) and pd.notna(df.loc[df.index[i], "ote_end"]):
            # Fallback to OTE if OB not valid
            df.loc[df.index[i], "zone_start"] = df.loc[df.index[i], "ote_start"]
            df.loc[df.index[i], "zone_end"] = df.loc[df.index[i], "ote_end"]
            df.loc[df.index[i], "zone_type"] = "OTE"

    return df
