def detect_order_blocks(df, bos_swing_ranges, direction):
    """
    Detect valid Order Blocks (OB) within BOS or CHoCH swing ranges.
    Fallback to OTE if no OB is found.

    Parameters:
    - df: DataFrame with OHLCV and BOS/CHoCH markers
    - bos_swing_ranges: List of tuples with (start_idx, end_idx) for BOS/CHoCH
    - direction: "bullish" or "bearish"

    Returns:
    - df: with columns 'is_ob', 'ob_start', 'ob_end', 'ob_direction'
    """
    df = df.copy()
    df["is_ob"] = False
    df["ob_start"] = None
    df["ob_end"] = None
    df["ob_direction"] = None

    for start_idx, end_idx in bos_swing_ranges:
        if direction == "bullish":
            for i in range(end_idx, start_idx - 1, -1):
                candle = df.iloc[i]
                # OB candidate: last bearish candle before bullish break
                if candle["Close"] < candle["Open"]:
                    # FVG check: candle low < next low AND candle high < prev high
                    if i+1 < len(df) and i-1 >= 0:
                        next_low = df.iloc[i+1]["Low"]
                        prev_high = df.iloc[i-1]["High"]
                        if candle["Low"] < next_low and candle["High"] < prev_high:
                            df.at[df.index[i], "is_ob"] = True
                            df.at[df.index[i], "ob_start"] = candle["Low"]
                            df.at[df.index[i], "ob_end"] = candle["High"]
                            df.at[df.index[i], "ob_direction"] = "bullish"
                            break  # take only one OB

        elif direction == "bearish":
            for i in range(end_idx, start_idx - 1, -1):
                candle = df.iloc[i]
                # OB candidate: last bullish candle before bearish break
                if candle["Close"] > candle["Open"]:
                    if i+1 < len(df) and i-1 >= 0:
                        next_high = df.iloc[i+1]["High"]
                        prev_low = df.iloc[i-1]["Low"]
                        if candle["High"] > next_high and candle["Low"] > prev_low:
                            df.at[df.index[i], "is_ob"] = True
                            df.at[df.index[i], "ob_start"] = candle["Low"]
                            df.at[df.index[i], "ob_end"] = candle["High"]
                            df.at[df.index[i], "ob_direction"] = "bearish"
                            break

    return df
