import pandas as pd

def detect_stop_hunts(df):
    """
    Detect stop hunts inside HTF OB/OTE zones.

    A stop hunt is defined as:
    - Price wicks into the OB/OTE zone
    - But candle does NOT close beyond the zone boundary
    - This represents a liquidity grab without displacement

    Adds:
    - is_stop_hunt: True/False for each candle
    """
    df = df.copy()
    df["is_stop_hunt"] = False

    for i in range(len(df)):
        zone_start = df.loc[df.index[i], "zone_start"]
        zone_end = df.loc[df.index[i], "zone_end"]
        close = df.loc[df.index[i], "Close"]
        high = df.loc[df.index[i], "High"]
        low = df.loc[df.index[i], "Low"]

        if pd.isna(zone_start) or pd.isna(zone_end):
            continue

        # 🟩 Bullish zone: price dips into zone but closes above
        if zone_start < zone_end:
            if low <= zone_start and close > zone_start:
                df.loc[df.index[i], "is_stop_hunt"] = True

        # 🟥 Bearish zone: price spikes into zone but closes below
        elif zone_start > zone_end:
            if high >= zone_start and close < zone_start:
                df.loc[df.index[i], "is_stop_hunt"] = True

    return df
