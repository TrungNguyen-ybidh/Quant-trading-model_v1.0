import pandas as pd

def generate_entry_signals(df):
    """
    Generate entry signals after LTF market structure confirmation inside HTF OB/OTE.

    Entry only when:
    - Inside HTF OB/OTE zone
    - LTF CHoCH confirmed
    - Optional: BOS or Stop Hunt
    - Then enter at OB/OTE start

    Adds:
    - is_entry: True/False
    - entry_price: price at OB or OTE start
    """
    df = df.copy()
    df["is_entry"] = False
    df["entry_price"] = None

    in_zone = False
    choch_confirmed = False
    bos_confirmed = False

    for i in range(len(df)):
        row = df.iloc[i]

        # Ensure we are inside OB/OTE zone
        if pd.isna(row["zone_start"]) or pd.isna(row["zone_end"]):
            continue

        price = row["Close"]
        zone_low = min(row["zone_start"], row["zone_end"])
        zone_high = max(row["zone_start"], row["zone_end"])

        in_zone = zone_low <= price <= zone_high

        if in_zone:
            if row.get("is_ltf_choch", False):
                choch_confirmed = True

            if row.get("is_ltf_bos", False):
                bos_confirmed = True

            if choch_confirmed:
                # Prefer OB if available
                if row.get("is_ob", False):
                    entry_price = row.get("ob_start")
                else:
                    entry_price = row.get("zone_start")  # OTE fallback

                df.at[df.index[i], "is_entry"] = True
                df.at[df.index[i], "entry_price"] = entry_price
                # Stop after first entry signal
                break

    return df
